gsap.registerPlugin(ScrollTrigger);

function wrapCharacters(selector) {
    document.querySelectorAll(selector).forEach(el => {
        const text = el.innerText;
        el.innerHTML = '';
        text.split('').forEach(char => {
            const span = document.createElement('span');
            span.innerText = char === ' ' ? '\u00A0' : char;
            span.classList.add('char');
            el.appendChild(span);
        });
    });
}

// 1. CURSOR CIRÚRGICO (Velocidade do ring aumentada de 0.25 pra 0.1)
class TacticalCursor {
    constructor() {
        this.cursor = document.getElementById('tactical-cursor');
        if(!this.cursor) return;
        this.dot = this.cursor.querySelector('.cursor-dot');
        this.ring = this.cursor.querySelector('.cursor-crosshair');
        
        // Ponto segue o mouse instantaneamente
        this.xToDot = gsap.quickTo(this.dot, "x", { duration: 0, ease: "none" });
        this.yToDot = gsap.quickTo(this.dot, "y", { duration: 0, ease: "none" });
        // O anel tem um micro-delay muito rápido para parecer fluido e não quebrado
        this.xToRing = gsap.quickTo(this.ring, "x", { duration: 0.1, ease: "power2.out" });
        this.yToRing = gsap.quickTo(this.ring, "y", { duration: 0.1, ease: "power2.out" });

        window.addEventListener('mousemove', (e) => {
            this.xToDot(e.clientX); this.yToDot(e.clientY);
            this.xToRing(e.clientX); this.yToRing(e.clientY);
        });

        document.querySelectorAll('.interactive-target, a, article').forEach(el => {
            el.addEventListener('mouseenter', () => document.body.classList.add('hover-engaged'));
            el.addEventListener('mouseleave', () => document.body.classList.remove('hover-engaged'));
        });
    }
}

// 2. FLUID AURA ENGINE (Vibe Antigravity - Orbes Fluidos e Misteriosos)
class FluidAuraEngine {
    constructor() {
        this.canvas = document.getElementById('kinetic-mesh-engine');
        if(!this.canvas) return;
        this.ctx = this.canvas.getContext('2d');
        this.orbs = [];
        this.mouse = { x: window.innerWidth/2, y: window.innerHeight/2, active: false };
        this.init();
        
        window.addEventListener('resize', () => this.init());
        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
            this.mouse.active = true;
        });
        window.addEventListener('mouseout', () => this.mouse.active = false);
    }

    init() {
        this.w = this.canvas.width = window.innerWidth;
        this.h = this.canvas.height = window.innerHeight;
        this.orbs = [];
        
        // Criar grandes orbes de cores profundas (Vibe Antigravity)
        // Cores suaves para Light Mode
        const colors = [
            'rgba(124, 58, 237, 0.1)',  // Light Purple
            'rgba(6, 182, 212, 0.1)',   // Light Cyan
            'rgba(243, 244, 246, 0.5)', // Grayish
            'rgba(16, 185, 129, 0.08)', // Soft Emerald
            'rgba(124, 58, 237, 0.05)'  // Very Light Purple
        ];

        for (let i = 0; i < 5; i++) {
            this.orbs.push({
                x: Math.random() * this.w,
                y: Math.random() * this.h,
                vx: (Math.random() - 0.5) * 1.2,
                vy: (Math.random() - 0.5) * 1.2,
                radius: Math.random() * 300 + 400,
                color: colors[i % colors.length]
            });
        }

        // Partículas soltas (Poeira estelar interativa)
        this.particles = [];
        for (let i = 0; i < 80; i++) {
            this.particles.push({
                x: Math.random() * this.w,
                y: Math.random() * this.h,
                vx: (Math.random() - 0.5) * 0.8,
                vy: (Math.random() - 0.5) * 0.8,
                baseRadius: Math.random() * 1.5 + 0.5,
                alpha: Math.random() * 0.5 + 0.1
            });
        }
    }

    render() {
        if(!this.ctx) return;
        this.ctx.clearRect(0, 0, this.w, this.h);
        
        this.orbs.forEach((orb, i) => {
            orb.x += orb.vx;
            orb.y += orb.vy;

            // Rebate nas bordas (com margem)
            if (orb.x < -orb.radius) orb.vx *= -1;
            if (orb.x > this.w + orb.radius) orb.vx *= -1;
            if (orb.y < -orb.radius) orb.vy *= -1;
            if (orb.y > this.h + orb.radius) orb.vy *= -1;

            // O cursor do mouse atrai sutilmente alguns orbes
            if (this.mouse.active && (i === 0 || i === 1)) {
                let dx = this.mouse.x - orb.x;
                let dy = this.mouse.y - orb.y;
                orb.x += dx * 0.015;
                orb.y += dy * 0.015;
            }

            // Gradiente radial
            let gradient = this.ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.radius);
            gradient.addColorStop(0, orb.color);
            gradient.addColorStop(1, 'rgba(255,255,255,0)');

            // Blend multiply para criar aquele efeito translúcido no fundo branco
            this.ctx.globalCompositeOperation = 'multiply';
            this.ctx.fillStyle = gradient;
            this.ctx.beginPath();
            this.ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
            this.ctx.fill();
        });

        // Desenhar partículas
        this.ctx.globalCompositeOperation = 'multiply';
        this.particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;

            // Warp edges
            if (p.x < 0) p.x = this.w;
            if (p.x > this.w) p.x = 0;
            if (p.y < 0) p.y = this.h;
            if (p.y > this.h) p.y = 0;

            // Desvio elegante do cursor do mouse
            if (this.mouse.active) {
                let dx = p.x - this.mouse.x;
                let dy = p.y - this.mouse.y;
                let dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 120) {
                    let force = (120 - dist) / 120;
                    p.x += (dx / dist) * force * 3;
                    p.y += (dy / dist) * force * 3;
                }
            }

            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.baseRadius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(6, 182, 212, ${p.alpha})`; // Darker cyan for light background
            this.ctx.fill();
        });
    }
}

// 3. ORQUESTRADOR E ANIMAÇÕES GSAP
class EliteOrchestrator {
    constructor() {
        wrapCharacters('.split-text');
        
        this.cursor = new TacticalCursor();
        this.mesh = new FluidAuraEngine();
        
        this.lenis = new Lenis({ lerp: 0.08, smooth: true });
        this.lenis.on('scroll', ScrollTrigger.update);
        
        this.probeDataY = document.getElementById('probe-y');

        this.initGSAP();
        
        // Ativa os 6 recursos Masterpiece
        this.masterpiece = new MasterpieceFeatures(this.lenis);

        gsap.ticker.add((time) => {
            this.lenis.raf(time * 1000);
            this.mesh.render();
            if(this.probeDataY) this.probeDataY.innerText = Math.floor(this.lenis.animatedScroll);
        });
        gsap.ticker.lagSmoothing(0);
    }

    initGSAP() {
        // Kinetic 3D Snap (Apple-like Domino Effect)
        gsap.set('#main-title .char', { y: 150, rotateX: -90, opacity: 0, transformOrigin: "50% 50% -50" });
        gsap.to('#main-title .char', { 
            y: 0, rotateX: 0, opacity: 1, 
            duration: 1.2, stagger: 0.04, ease: "power4.out", delay: 0.1 
        });
        
        // Reveals
        gsap.utils.toArray('.gsap-reveal').forEach(el => {
            gsap.to(el, { y: 0, opacity: 1, duration: 1, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 85%" } });
        });

        // Contadores
        document.querySelectorAll('.counter-float').forEach(c => {
            gsap.to(c, { textContent: parseFloat(c.getAttribute('data-target')), duration: 2, ease: "power2.out", snap: { textContent: 0.01 }, scrollTrigger: { trigger: c, start: "top 85%" } });
        });
        document.querySelectorAll('.counter-int').forEach(c => {
            gsap.to(c, { textContent: parseInt(c.getAttribute('data-target')), duration: 2, ease: "power2.out", snap: { textContent: 1 }, scrollTrigger: { trigger: c, start: "top 85%" }, onUpdate: function() { c.innerHTML = Math.ceil(this.targets()[0].textContent).toLocaleString(); } });
        });

        // SVG Chart Latency
        const path = document.getElementById('latency-path');
        const nodes = gsap.utils.toArray('.chart-node');
        if(path) {
            const l = path.getTotalLength();
            gsap.set(path, { strokeDasharray: l, strokeDashoffset: l });
            gsap.timeline({ scrollTrigger: { trigger: ".latency-chart", start: "top 80%" } })
                .to(path, { strokeDashoffset: 0, duration: 1.5, ease: "power2.inOut" })
                .to(nodes, { opacity: 1, duration: 0.5, stagger: 0.2 }, "-=0.5");
        }

        // Fios de Energia interagindo com o Scroll
        gsap.to('.data-wire', {
            strokeDashoffset: -200, // Faz a energia fluir mais rápido no scroll
            ease: "none",
            scrollTrigger: {
                trigger: "#dashboard",
                start: "top bottom",
                end: "bottom top",
                scrub: 0.5
            }
        });

        // Brilho dos Cards do Mouse
        document.querySelectorAll('.glass-card, .vault-card, .video-frame').forEach(c => {
            c.addEventListener('mousemove', e => {
                const r = c.getBoundingClientRect();
                c.style.setProperty('--mx', `${e.clientX - r.left}px`);
                c.style.setProperty('--my', `${e.clientY - r.top}px`);
            });
        });

        // HORIZONTAL SCROLL (ARSENAL)
        const track = document.getElementById('horizontal-track');
        if(track) {
            // A largura total que precisamos mover é o tamanho do track menos a tela visível
            let trackWidth = track.scrollWidth - window.innerWidth;
            gsap.to(track, {
                x: () => - (track.scrollWidth - window.innerWidth + 100), // +100px padding extra no final
                ease: "none",
                scrollTrigger: {
                    trigger: "#arsenal",
                    pin: true,
                    scrub: 1,
                    start: "top top",
                    end: () => `+=${track.scrollWidth}`, // Duração do scroll baseada na largura
                    invalidateOnRefresh: true
                }
            });
        }

        // ARCHITECTURE INTERACTIVE SCROLL
        const archSection = document.getElementById('architecture');
        const wireMain = document.getElementById('wire-main');
        const wireBranch = document.getElementById('wire-branch');
        
        if(archSection && wireMain && wireBranch) {
            const l1 = wireMain.getTotalLength();
            const l2 = wireBranch.getTotalLength();
            
            // Set initial state
            gsap.set(wireMain, { strokeDasharray: l1, strokeDashoffset: l1 });
            gsap.set(wireBranch, { strokeDasharray: l2, strokeDashoffset: l2 });
            gsap.set('.arch-node circle, .arch-node rect', { fill: 'var(--sys-surface)', stroke: 'rgba(255,255,255,0.2)' });
            gsap.set('.arch-step', { opacity: 0.2, x: -20 });

            const archTl = gsap.timeline({
                scrollTrigger: {
                    trigger: "#architecture",
                    start: "top 40%",
                    end: "bottom 80%",
                    scrub: 1
                }
            });

            // 1. Ingress
            archTl.to('#node-ingress circle:not(.node-pulse)', { stroke: 'var(--brand-cyan)', fill: 'rgba(0,240,255,0.1)', duration: 0.1 })
                  .to('#step-1', {opacity: 1, x: 0, duration: 0.5}, "<");
            
            // 2. Draw line to Kafka
            archTl.to(wireMain, { strokeDashoffset: l1 * 0.45, duration: 1 })
                  .to('#node-kafka rect', { stroke: 'var(--brand-purple)', fill: 'rgba(138,43,226,0.1)', duration: 0.1 })
                  .to('#step-2', {opacity: 1, x: 0, duration: 0.5}, "<");

            // 3. Draw lines to Workers
            archTl.to(wireMain, { strokeDashoffset: 0, duration: 1 })
                  .to(wireBranch, { strokeDashoffset: 0, duration: 1 }, "<")
                  .to('#node-worker1 circle, #node-worker2 circle', { stroke: 'var(--brand-cyan)', fill: 'rgba(0,240,255,0.1)', duration: 0.1 })
                  .to('#step-3', {opacity: 1, x: 0, duration: 0.5}, "<");
        }
    }
}

// 4. THE 6 MASTERPIECE FEATURES
class MasterpieceFeatures {
    constructor(lenis) {
        this.lenis = lenis;
        this.initCmdPalette();
        this.initTerminal();
        this.initMagneticUX();
        this.init3DTilt();
        this.initTimeline();
        this.initLiquidFooter();
        this.initProjectVault();
    }
    
    initProjectVault() {
        const theater = document.getElementById('project-theater');
        const titleEl = document.getElementById('theater-title');
        const descEl = document.getElementById('theater-desc');
        
        if(!theater) return;

        document.querySelectorAll('.project-showcase-card').forEach(card => {
            const playWrap = card.querySelector('.explore-btn');
            const titleText = card.querySelector('h3').innerText;
            const descText = card.querySelector('p').innerText;
            
            if(playWrap) {
                playWrap.addEventListener('click', (e) => {
                    e.preventDefault();
                    titleEl.innerText = titleText;
                    descEl.innerText = descText;
                    
                    const logo = document.querySelector('.hud-brand img');
                    
                    if(logo) {
                        const logoRect = logo.getBoundingClientRect();
                        const centerX = window.innerWidth / 2;
                        const centerY = window.innerHeight / 2;
                        
                        const tx = centerX - (logoRect.left + logoRect.width / 2);
                        const ty = centerY - (logoRect.top + logoRect.height / 2);
                        
                        const tl = gsap.timeline();
                        
                        // 1. Puxa a logo pro meio, girando e aumentando
                        tl.to(logo, { x: tx, y: ty, scale: 6, rotation: 180, duration: 0.6, ease: "power4.inOut" })
                        // 2. Logo desaparece (implosão)
                          .to(logo, { scale: 0, opacity: 0, duration: 0.3, ease: "power2.in" })
                        // 3. Abre o ambiente do centro
                          .add(() => { theater.classList.add('active'); }, "-=0.1")
                          .fromTo(theater, 
                              { clipPath: `circle(0% at 50% 50%)` },
                              { clipPath: `circle(150% at 50% 50%)`, duration: 0.8, ease: "power3.inOut" },
                              "-=0.2"
                          );
                    } else {
                        // Fallback caso não tenha logo
                        theater.classList.add('active');
                        gsap.fromTo(theater, { clipPath: `circle(0% at 50% 50%)` }, { clipPath: `circle(150% at 50% 50%)`, duration: 0.8, ease: "power3.inOut" });
                    }
                });
            }
        });
    }

    closeTheater() {
        const theater = document.getElementById('project-theater');
        const logo = document.querySelector('.hud-brand img');
        
        if(theater) {
            const tl = gsap.timeline();
            
            // 1. Fecha o ambiente (implosão da tela negra)
            tl.to(theater, {
                clipPath: `circle(0% at 50% 50%)`, duration: 0.6, ease: "power3.inOut",
                onComplete: () => theater.classList.remove('active')
            });
            
            // 2. Devolve a logo
            if(logo) {
                // A logo reaparece no centro
                tl.to(logo, { scale: 6, opacity: 1, duration: 0.3, ease: "power2.out" }, "-=0.4")
                  // Volta para o canto
                  .to(logo, { x: 0, y: 0, scale: 1, rotation: 0, duration: 0.6, ease: "power3.inOut" });
            }
        }
    }

    initCmdPalette() {
        const overlay = document.getElementById('cmd-palette-overlay');
        const input = document.getElementById('cmd-input');
        
        window.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                overlay.classList.toggle('active');
                if(overlay.classList.contains('active')) input.focus();
            }
            if (e.key === 'Escape' && overlay.classList.contains('active')) {
                overlay.classList.remove('active');
            }
        });
    }

    initTerminal() {
        const term = document.getElementById('tactical-terminal');
        const header = term.querySelector('.term-header');
        const input = document.getElementById('term-input');
        const body = document.getElementById('term-body');

        // Make draggable
        let isDragging = false, startX, startY, initialX, initialY;
        header.addEventListener('mousedown', e => {
            isDragging = true;
            startX = e.clientX; startY = e.clientY;
            initialX = term.offsetLeft; initialY = term.offsetTop;
        });
        window.addEventListener('mousemove', e => {
            if(!isDragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            term.style.left = `${initialX + dx}px`;
            term.style.top = `${initialY + dy}px`;
            term.style.right = 'auto'; // Reset right anchor
        });
        window.addEventListener('mouseup', () => isDragging = false);

        // Command Engine
        input.addEventListener('keydown', e => {
            if(e.key === 'Enter') {
                const cmd = input.value.trim().toLowerCase();
                input.value = '';
                
                let response = '';
                if(cmd === 'whoami') response = 'Pedro Leanza - Especialista em Arquiteturas Escaláveis.';
                else if(cmd === 'contact') response = 'E-mail: leanzapedro@gmail.com | IG: @__leanza__ | Tel: 11933283001';
                else if(cmd === 'skills') response = 'Go, Rust, Node.js, React, Kafka, Redis, PostgreSQL, Kubernetes.';
                else if(cmd === 'clear') { 
                    const lines = body.querySelectorAll('.term-line');
                    lines.forEach(l => l.remove());
                    return; 
                }
                else if(cmd === 'help') response = 'Comandos: whoami, contact, skills, clear.';
                else if(cmd !== '') response = `Command not found: ${cmd}`;

                if(cmd !== '') {
                    const lineCmd = document.createElement('div');
                    lineCmd.className = 'term-line text-white';
                    lineCmd.innerHTML = `<span class="text-cyan">$</span> ${cmd}`;
                    body.insertBefore(lineCmd, input.parentElement);

                    if(response) {
                        const lineRes = document.createElement('div');
                        lineRes.className = 'term-line';
                        lineRes.innerText = response;
                        body.insertBefore(lineRes, input.parentElement);
                    }
                    body.scrollTop = body.scrollHeight;
                }
            }
        });
    }

    initMagneticUX() {
        document.querySelectorAll('.magnetic-wrap').forEach(wrap => {
            const btn = wrap.querySelector('.magnetic-btn') || wrap.firstElementChild;
            
            wrap.addEventListener('mousemove', (e) => {
                const rect = wrap.getBoundingClientRect();
                const hx = (e.clientX - rect.left) - rect.width / 2;
                const hy = (e.clientY - rect.top) - rect.height / 2;
                
                // Puxa o botão com força magnética
                gsap.to(btn, { x: hx * 0.4, y: hy * 0.4, duration: 0.5, ease: "power3.out" });
            });
            wrap.addEventListener('mouseleave', () => {
                gsap.to(btn, { x: 0, y: 0, duration: 0.7, ease: "elastic.out(1, 0.3)" });
            });
        });
    }

    init3DTilt() {
        document.querySelectorAll('.tilt-wrapper').forEach(wrapper => {
            const el = wrapper.querySelector('.tilt-element');
            const glare = wrapper.querySelector('.glare');
            
            wrapper.addEventListener('mousemove', e => {
                const rect = wrapper.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const cx = rect.width / 2;
                const cy = rect.height / 2;
                
                const tiltX = ((y - cy) / cy) * -10; // Max 10 deg
                const tiltY = ((x - cx) / cx) * 10;
                
                gsap.to(el, { rotateX: tiltX, rotateY: tiltY, duration: 0.5, ease: "power2.out", transformPerspective: 1000 });
                
                if(glare) {
                    gsap.to(glare, { x: x - cx * 2, y: y - cy * 2, opacity: 1, duration: 0.2 });
                }
            });
            wrapper.addEventListener('mouseleave', () => {
                gsap.to(el, { rotateX: 0, rotateY: 0, duration: 0.7, ease: "power2.out" });
                if(glare) gsap.to(glare, { opacity: 0, duration: 0.5 });
            });
        });
    }

    initTimeline() {
        const laser = document.getElementById('timeline-laser');
        const items = gsap.utils.toArray('.timeline-item');
        
        if(!laser || items.length === 0) return;

        // Anima o laser principal descendo
        gsap.to(laser, {
            height: "100%",
            ease: "none",
            scrollTrigger: {
                trigger: ".timeline-container",
                start: "top 60%",
                end: "bottom 60%",
                scrub: 1
            }
        });

        // Acende os itens assim que o laser passa por eles
        items.forEach(item => {
            ScrollTrigger.create({
                trigger: item,
                start: "top 60%",
                onEnter: () => item.classList.add('active'),
                onLeaveBack: () => item.classList.remove('active')
            });
        });
    }

    initLiquidFooter() {
        const btn = document.getElementById('copy-email-btn');
        const text = document.getElementById('massive-text');
        
        if(!btn || !text) return;

        btn.addEventListener('click', (e) => {
            navigator.clipboard.writeText('leanzapedro@gmail.com');
            text.innerHTML = "EMAIL<br>COPIED!";
            text.style.color = 'var(--brand-cyan)';
            
            // Generate particles
            for(let i=0; i<25; i++) {
                const p = document.createElement('div');
                p.className = 'contact-particle';
                p.style.width = Math.random() * 8 + 4 + 'px';
                p.style.height = p.style.width;
                p.style.left = e.clientX + 'px';
                p.style.top = e.clientY + 'px';
                
                const tx = (Math.random() - 0.5) * 300;
                const ty = (Math.random() - 0.5) * 300;
                p.style.setProperty('--tx', `${tx}px`);
                p.style.setProperty('--ty', `${ty}px`);
                
                document.body.appendChild(p);
                setTimeout(() => p.remove(), 800);
            }
            
            setTimeout(() => {
                text.innerHTML = "LET'S BUILD<br>SOMETHING.";
                text.style.color = 'var(--text-white)';
            }, 3000);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => { window.App = new EliteOrchestrator(); });